<?php

declare(strict_types=1);

namespace Doctrine\DBAL\Schema\Collections;

use Doctrine\DBAL\Schema\SchemaException;

/** @internal */
interface Exception extends SchemaException
{
}
